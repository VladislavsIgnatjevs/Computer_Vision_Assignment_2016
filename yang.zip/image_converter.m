% Computer vision assignment
% convert images to matrices with gui

% @author Yang Xu
% @author Wei Li
% @author Vladislavs Ignatjevs

clear all


global err numTiles subtile numPixelsWidth numPixelsHeight generateButton output_folder_path InputFileName InputPathName InputFilterIndex input_folder_path input_training_path TrainingFileName fileNameArray out
gui1;


%image_test = imread('Images\out_manmade_1k\sun_aaasertfihkcjvdd.jpg');





