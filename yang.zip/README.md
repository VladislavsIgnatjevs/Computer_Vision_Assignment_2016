# Computer_Vision_Assignment_2016
computer vision assignment 2016

Computer Vision 2016 assignment
(Generating composite image from image set)

authors:
Vladislavs Ignatjevs
Yang Xu
Wei Li

To run the project clone the repo and run "image_converter.m"
